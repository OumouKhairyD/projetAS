package com.example.projeto;

import android.os.Bundle;
import android.widget.CheckBox;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.projeto.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    Spinner spinner1,spinner2;
    CheckBox check;
    Button valider, supprimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        app= findViewById(R.id.app);
        fins= findViewById(R.id.fins);
        prenom= findViewById(R.id.prenom);
        nom= findViewById(R.id.nom);
        mail= findViewById(R.id.mail);
        tel= findViewById(R.id.tel);
        spinner1= findViewById(R.id.spinner1);
        spinner2= findViewById(R.id.spinner2);
        check= findViewById(R.id.check);
        valider= findViewById(R.id.valider);
        supprimer= findViewById(R.id.supprimer);




    }

}